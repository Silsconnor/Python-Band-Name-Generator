#1. Create a greeting for your program.
print("Welcome!")
#2. Ask the user for the city that they grew up in.
city =input("Where did you grow up?")
#3. Ask the user for the name of a pet.
pet = input("What is the name of your pet?")
#4. Combine the name of their city and pet and show them their band name.
print("it could be called " + city  + " " +  pet)
